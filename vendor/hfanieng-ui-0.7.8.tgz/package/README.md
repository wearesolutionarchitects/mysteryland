# @hfanieng/ui

## 0.7.8: Suche über Tabellenspalten

Ein Tabellenfilter kann mit `scope: 'row'` alle Inhaltsspalten derselben Zeile durchsuchen. Aktionszellen bleiben ausgenommen; ohne diese Option bleibt die Suche auf die konfigurierte Spalte beschränkt. Weitere Spaltenfilter können damit kombiniert werden.

## 0.7.7: Mehrwortsuche in Tabellen

Tabellenfilter können mit `mode: 'terms'` alle durch Leerraum getrennten Suchbegriffe unabhängig von ihrer Reihenfolge abgleichen. `minCharacters` setzt optional die Mindestzahl an Buchstaben oder Ziffern; ohne diese Optionen bleiben zusammenhängende Suche und drei Zeichen als Standard erhalten.

## 0.7.6: Fixierte Tabellensteuerung

`DataTable` unterstützt einen gemeinsamen Controls-Slot für Kennzahlen,
fixierte Karten und Filter sowie einen separat scrollbaren Listenbereich mit
fixierter Tabellenüberschrift. Filteraktionen, Platzhalter und zugängliche
Scrollbereiche sind optional. Das Archiv enthält auch den aktuellen Stand der
übrigen gemeinsamen Komponenten.

## 0.7.5: Sichtbare Tabellenfelder und eindeutige Disclosure-Pfeile

Tabellen berücksichtigen die feste Aktionsspalte beim Fokussieren und automatischen
Scrollen von Eingabefeldern. `--data-table-actions-width` steuert bei Bedarf die
gemeinsame Mindestbreite und den Scrollabstand. `Disclosure` erhält ausschließlich
sein zentrales Chevron-Icon; der native Details-Fallback bleibt für einfache
`details` verfügbar.

## 0.7.4: Einheitliche Tabellenmarker und Aktionsicons

Tabellen erhalten einen roten Inhaltsmarker je Datenzeile in der ersten Inhaltszelle,
auch wenn davor eine feste Aktionsspalte steht. Navigation und Aktionszellen bleiben
ohne Marker. Drawer und Flash-Meldungen verwenden das zentrale Close-Icon; Icons
in Textbuttons behalten ihre Größe. `Disclosure` reicht native Attribute durch und
bietet `data-disclosure-title` sowie `data-disclosure-content` für dynamisch geklonte Inhalte.

## 0.7.3: Formularraster begrenzen

`ActionForm` und damit `CrudForm` begrenzen ihre Grid-Spalte auf den verfügbaren
Platz; breite Tabellen bleiben im eigenen Scrollcontainer, lange Aktionsbeschriftungen
vergrößern nicht die Seite.

## 0.7.2: Fixierter Seitenkontext im gemeinsamen Header

`SidebarShell` bietet den Slot `context` in der zweiten, flexiblen Header-Spalte.
Brand/Navigation stehen links, Aktionen rechts. Die Geometrie folgt dem Heiko-
Runtime-Header. Ein ResizeObserver hält den Sidebar-Abstand auch bei mehrzeiligem
Seitenkontext aktuell. Auf kleinen Displays wird der Brand-Link mit Home-Icon angezeigt.


## Gemeinsame Lucide-Icons

`@hfanieng/ui/icon` exportiert dieselbe `Icon`-Komponente für Astro und Preact.
Die fachlichen Namen und ihre Lucide-Zuordnung stehen ausschließlich in
`src/Icon.tsx`; Strichstärke 2, Größe über `size`, Farbe über `currentColor`.
Beispiel: `<Icon name="review" size={16} />` verwendet `FlaskRound` für die
ECHA-Prüfung. Dekorative Icons sind `aria-hidden`; Link/Button liefern Label und
Tooltip. Ein eigenständiges Symbol erhält `label` und damit `role="img"`.
Keine lokalen SVG-Kopien oder zusätzlichen Lucide-Imports in Consumern pflegen.
Die Abhängigkeit `lucide-preact` liefert nur die ausgewählten Icons. Vorhandene
Markenlogos bleiben in `BrandIcon.tsx`, da Lucide v1 keine Markenlogos enthält.
GHS-Piktogramme, Fachdiagramme und eigene Markenlogos sind separate Fachgrafiken.

## 0.7.1: Listenmarker ohne Navigationsmarker

Nummerierte Listen behalten ihre Nummerierung ohne zusätzliche Rechteckmarker.
Navigation einschließlich Breadcrumbs erhält keine Inhaltsmarker. Tabellen-Scrollcontainer
binden absolut positionierte Formularfelder, damit diese keinen Seitenüberlauf erzeugen.

## 0.7.0: Breadcrumbs und gemeinsame Aktionsformulare

`@hfanieng/ui/breadcrumbs` rendert eine zugängliche, umbrechende Header-Navigation
aus `items: { label, href? }[]`. Eltern sind Links; der letzte Eintrag bleibt Text
mit `aria-current="page"`. Die fachliche Hierarchie gehört dem jeweiligen Consumer.

`@hfanieng/ui/action-form` liefert das gemeinsame Formularlayout mit Aktionsleiste,
Hidden-Feldern, Slots und optionalem Abbrechen-Link. `intentName` erhält vorhandene
Serververträge; `fieldLayout="stack"` erlaubt fachliche Feldgruppen im Slot.
`CrudForm` delegiert an denselben Baustein und ergänzt ausschließlich die
Create-/Update-Defaults. Abrufe und Vorschläge verwenden `ActionForm` mit einer
zutreffenden Beschriftung. Native Formularattribute bleiben verfügbar.

Die Version ersetzt keine veröffentlichten Archive. Andere Projekte übernehmen
den neuen Stand später über ein eigenes versioniertes Archiv und ihren Lockfile.

## 0.6.2: Shared workspace geometry and refreshed lists

`@hfanieng/ui/workspace.css` owns the sidebar/header dimensions, content gutters,
intro typography and section/panel spacing used by Heiko internal and the career
cockpit. SidebarShell uses a 17.5rem sidebar, a 4rem minimum header and the same
850px mobile breakpoint as Heiko internal. Consumers apply the `--workspace-*`
variables to their existing layout; application navigation and authentication stay
with the consumer.

Client lists use `ListView` with a `DataTable` in the table slot for shared sorting
and pagination. After replacing table rows, dispatch `table-rows-change` on the
`[data-filterable-table]` container to reapply the active sort and return to page 1.
Use `data-no-sort` on action headers. Tag styles are available through
`@hfanieng/ui/tag-list.css` without a consumer copy.

Small, themeable Astro components maintained by Heiko Fanieng. Licensed under [MIT](./LICENSE).

Version 0.6.0 consolidates buttons, forms, tables, pagination, disclosures and feedback under one semantic styling contract. SidebarShell and NavigationList remain available. It contains no private runtime dependencies, global theme, fonts or brand assets. Requires Astro 7.3.1 or a compatible 7.x version; the consuming Astro application compiles the included, editable source.

## Install

Install the prepared local 0.6.0 archive (use its actual path):

```sh
npm install --save-exact "/absolute/path/to/hfanieng-ui-0.6.0.tgz"
```

Commit the resulting package-lock.json. This package is distributed through public Mysteryland GitHub Releases; no npm login or private repository access is required. npm remains the package manager. Version 0.1.0 on npm is an earlier distribution experiment. The manifest sets private: true to prevent accidental npm publishing; this does not prevent installation from a release archive. Published assets must not be replaced: changed contents require a new version.

## Usage

```astro
---
import ActionButton from '@hfanieng/ui/action-button';
---
<ActionButton variant="secondary" aria-label="Previous ticket" data-ticket-slider-prev>
  Previous
</ActionButton>
```

Supports native button attributes, including `disabled`, `name`, `value`, ARIA and `data-*`, and a default slot. `type` defaults to `button`; use `type="submit"` explicitly for form submission. `variant` is `primary` (default) or `secondary`.

## Styling contract

### Buttons and navigation links

Use `ActionButton` for actions and form submission. Use `LinkButton` from
`@hfanieng/ui/link-button` for navigation styled as a button:

```astro
<ActionButton type="submit">Speichern</ActionButton>
<LinkButton href="/records/" variant="secondary">Zurück zur Liste</LinkButton>
```

`LinkButton` requires `href`, defaults to `secondary`, and forwards native anchor
attributes. It remains a real link, including keyboard navigation and opening in
a new tab. Both components use the same rules in `controls.css`. `FilterBar`
uses these components for submit and reset; consumers should not style its
internal anchors.

Themes can set `--button-secondary-border` (default: `--color-border`) and
`--button-secondary-hover-background` (default: `--color-surface-muted`).
Focus and disabled button styling stay in the shared controls stylesheet.
The compliance suite sets these two variables to its accent colors.

These controls are included in 0.6.0. Consumers must explicitly adopt the new
archive and update their lockfile. Existing release archives must not be replaced.

Components load the common controls and low-priority neutral defaults automatically. Import `@hfanieng/ui/tokens.css` for defaults alone, or `@hfanieng/ui/controls.css` for plain HTML using `.button`, `.text-field`, `.select-field` or `.shared-textarea`. Application themes override semantic custom properties; defaults use the `fanieng.defaults` cascade layer, so ordinary theme declarations win regardless of import order.

| Purpose | Shared custom properties |
| --- | --- |
| Surfaces and text | `--color-bg`, `--color-surface`, `--color-surface-muted`, `--color-text`, `--color-text-muted`, `--color-border` |
| Actions | `--color-accent`, `--color-on-accent`, `--color-focus` |
| Status | `--color-status-success`, `--color-status-warning`, `--color-status-critical` |
| Typography | `--font-family-base`, `--font-weight-label`, `--font-weight-action`, `--font-size-hint` |
| Geometry | `--space-1` to `--space-4`, `--radius-small`, `--control-min-height`, `--control-padding-block`, `--control-padding-inline`, `--focus-width`, `--focus-offset` |

Minimum control height defaults to 2.75rem. Themes own foreground/background pairs and must validate their contrast. Primary/secondary, disabled, hover and focus rules live only in this package. A pressed button adds an inset mark without changing its theme text color. No global body reset or website layout is installed.

```css
:root {
  --color-accent: #004c93;
  --color-on-accent: #ffffff;
  --color-focus: #004c93;
  --font-family-base: system-ui, sans-serif;
}
```

Also exported: `@hfanieng/ui/form-field`, `@hfanieng/ui/text-field`, `@hfanieng/ui/select-field`. TextField accepts label, name, value, placeholder, native input type and hint. SelectField accepts label, name, value, placeholder, hint and options (`{value,label}[]`). FormField accepts label, name, hint, required and a slot. Existing compliance imports delegate to these implementations.

## Source and contributions

The canonical development source lives in the private heiko monorepo. The complete component source is included under `src/` in this MIT-licensed package; no package-specific build tooling is required.

Use the public [Mysteryland issue tracker](https://github.com/wearesolutionarchitects/mysteryland/issues) for bugs, questions and proposed changes. Prefix the issue title with `[@hfanieng/ui]` and include the package/Astro versions, expected behavior and a minimal reproduction. You can propose a source diff in the issue without access to heiko. The maintainer applies accepted shared changes in heiko and releases a new package version. Mysteryland's application source is a consumer, not a second copy of this component.

## Maintainer validation

In the heiko checkout, run `npm test --workspace @hfanieng/ui`. It packs the allowlisted files, installs the archive in an isolated Astro consumer and verifies its build and the existing compliance adapter. These repository tests are not part of the published package. Browser interaction checks are enabled separately from this build test.

For optional Chromium style checks, run the package test with UI_BROWSER_CHECK=1 after installing the repository Playwright browser. The CI package test still requires no browser installation.

## General controls (0.3.0)

- `@hfanieng/ui/file-dropzone`: label/name, optional id, accept, required, maximumFileSizeBytes, prompt/buttonLabel/emptyLabel/readyLabel and autoSubmit. Selects one file using the native picker or drag/drop. Validation updates native form validity and dispatches `file-dropzone:change` on document with `{id, file, error}`; invalid files produce no file in the event. Auto-submit calls the enclosing form's requestSubmit only for valid files. This control does not upload, store or parse documents. File validation on a receiving server remains that application's responsibility.
- `@hfanieng/ui/searchable-select`: name, options (`{value,label}[]`), optional value, placeholder, searchPlaceholder, minQueryLength, emptyText, searchUrl, searchParam, debounceMs and maxResults. Submits the selected value in a hidden input and emits its bubbling change event. A search endpoint returns an array or `{options: [...]}`. Arrow keys navigate results, Enter selects, Escape closes. Search requests are debounced and superseded requests cancelled. Application-specific endpoints and authorization remain in the consumer.
- `@hfanieng/ui/filter-bar`: GET form with a fields slot, optional actionLabel and resetHref. Uses the shared ActionButton; no filtering logic is included.

Existing compliance imports are compatibility adapters. Both package tests and optional Chromium tests exercise these adapters against the isolated archive, including drag/drop, validation, auto-submit, local/remote selection, keyboard navigation and GET/reset behavior.

## Tables, lists and feedback (included in 0.5.0)

DataTable, ListView, EmptyState, StatusBadge und FlashMessageCenter liegen ebenfalls im gemeinsamen Paket. Die bisherigen Compliance-Dateien delegieren an diese Implementierung. FlashMessageCenter verwendet Preact als Peer-Abhängigkeit; Astro-Consumers aktivieren `@astrojs/preact`. Tabellenfilter und Flash-Ereignisse sind über `table-filters` und `flash-message-events` zugänglich. Die bisherigen Ereignisnamen bleiben kompatibel.

Die zunächst als 0.4.0 vorbereiteten Controls sind im öffentlichen Release 0.5.0 enthalten. Anwendungen installieren das feste Mysteryland-Release-Archiv einschließlich Lockfile; ein heiko-Checkout ist nicht erforderlich.

## Sidebar navigation (0.5.0)

`@hfanieng/ui/sidebar-shell` provides a desktop sidebar and a native modal navigation drawer below 64rem. It accepts `brand`, `homeHref`, `items`, `currentPath`, and optional `id` and translated navigation/open/close/skip labels. Slots: default page content, `actions` for header controls, and `status` above the main content. Use one shell per page. The drawer supports Escape, focus restoration, backdrop dismissal and closes when switching to desktop.

`@hfanieng/ui/navigation-list` accepts items with `href`, `label`, optional `description` and `activePaths`. Exact pages receive `aria-current=page`; related record routes receive `aria-current=location`. Navigation data and authorization belong to the consumer. No compliance routes, authentication or private runtime dependencies are included.

Both components load the shared `shell.css`, which uses the existing semantic theme tokens. Consumers may override `--shell-sidebar-width` and `--shell-header-height` on `.fanieng-shell`. The existing heiko AppShell remains its website-specific composition; this package supplies the neutral shell used by the standalone Career app.

Version 0.5.1 aligns active navigation with Heiko: a rounded vertical accent rule on a transparent background. `--accent-rule-width` controls its width (default 3px). Both exact and related routes use this marker.

Version 0.5.2 adds a 1px semantic border around the scrollable DataTable, including tables used inside ListView. The frame uses `--color-border` and remains visible during horizontal scrolling.

Version 0.5.3 makes the 1px outer table frame more visible using muted text and surface tokens. Themes may override `--data-table-border-color`.

Version 0.5.4 adds alternating visible result rows and 1px internal row/column separators. Semantic colors adapt to light and dark themes. Override `--data-table-stripe-color` or `--data-table-grid-color` when needed. Hidden rows do not affect striping.

Navigation groups (0.5.5): pass `{ label, children: [...] }` without `href` to NavigationList/SidebarShell. Native details/summary toggles groups by mouse or keyboard; matching descendant routes open their ancestors. Optional group `activePaths` opens on exact paths (e.g. the app home). Leaf `activePaths` retains section matching. The same recursive renderer and theme tokens serve desktop and mobile navigation.

Version 0.5.6: groups may provide `href` to render a separate page link beside the disclosure control. Clicking the label navigates; the arrow toggles the submenu independently.

Version 0.5.7: `@hfanieng/ui/overview-card` renders rectangular summary and metric cards. Props: `title`, optional `value` (including zero), `description`, `href`; a default slot supports domain-specific content. Put cards in `.overview-card-grid` for a responsive layout. Colors and focus styles use shared theme tokens; cards have no rounded corners.

### Gemeinsame Listen und Pagination

`ListView` paginiert Tabellen standardmäßig im Browser mit 25 Einträgen pro Seite.
Die gemeinsame `Pagination` bietet 25, 50 und 100 Einträge, den Trefferbereich
und Vor-/Zurück-Navigation. Spaltenfilter werden vor der Seiteneinteilung auf alle
Zeilen angewendet; Größen- und Filterwechsel starten auf Seite 1. Dynamisch geladene
Zeilen werden berücksichtigt.

Für serverseitige Listen `Pagination` über den Slot `pagination` übergeben:
`page`, `pageSize`, `total`, `count`, `hasPrevious`, `hasNext`, `previousHref`, `nextHref`.
Der Größenwechsel nutzt GET mit `pageSize`, setzt `page=1` und erhält die übrigen
Suchparameter. Der Server muss die Größe validieren und nur die gewünschte Seite
laden. `@hfanieng/ui/pagination-state` exportiert die gemeinsamen UI-Größen und
`normalizePageSize`. Bei serverseitiger Pagination werden die geladenen Zeilen
nicht noch einmal im Browser paginiert.

### Einheitliche CRUD-Oberflächen

Die Komponenten bilden eine gemeinsame Oberfläche, keine generische Datenbank-Schicht:

| Aufgabe | Komponente | Vertrag |
| --- | --- | --- |
| Liste | `ListView`, `DataTable`, `Pagination` | Bestehende Suche, Seitengröße und Seitennavigation |
| Aktionen | `RecordActions` | Datensatzname und erlaubte URLs; nicht übergebene Aktionen fehlen |
| Anzeigen | `RecordDetails` | Beschriftete Werte und optionale Verknüpfungen |
| Anlegen / Bearbeiten | `CrudForm` | POST-Ziel, `mode`, optionale `intent`, versteckte Identitäts-/Versionsfelder, Felder im Standardslot |
| Löschen | `DeleteConfirmation` | POST-Ziel, Datensatzname, Identität/Version, ausdrückliche Bestätigung |

`RecordActions` übernimmt `viewLabel`, `editLabel` und `reviewLabel` jeweils identisch als Tooltip (`title`) und zugänglichen Namen (`aria-label`). Beschriftungen sollen die Aktion und eine kurze Datensatzidentität nennen.

Die Exporte heißen `record-actions`, `record-details`, `crud-form` und
`delete-confirmation`. `CrudForm` bietet zusätzliche Slots `hidden` und `actions`.
Vorhandene `FormField`, `TextField`, `SelectField` und `SearchableSelect` bleiben
die Bausteine für Eingabefelder. Die übergebene `intent` wird als POST-Feld
`action` versendet (Standard: `create` oder `update`). `DeleteConfirmation`
versendet `action=delete` und verlangt `confirm_delete=yes`. Die Komponente öffnet
einen modalen Dialog über den Auslöser oder mit `open` direkt nach dem Laden.
Abbrechen und Escape schließen den Dialog und geben den Fokus zurück; bei einem
direkt geöffneten Dialog führt `cancelHref` zurück in den Pflegekontext.
Die Bestätigung ist beim Öffnen immer unmarkiert. `TagList` unterstützt mit
`marker="rule"` die senkrechte Akzentlinie für kompakte Identifikationszeilen.

Berechtigungen, Same-Origin-Prüfung, fachliche Validierung, Fehlerbehandlung,
Versionskonflikte und Löschbarkeit müssen weiterhin serverseitig geprüft werden.
Eine ausgeblendete Aktion ersetzt keine Zugriffsprüfung. Fehler werden mit dem
bestehenden Flash-System angezeigt; die Route liefert die eingegebenen Werte
zurück. Keine Mutation erfolgt per GET. Identität und Versionsfelder bleiben im
jeweiligen Modul definiert, damit bestehende Schutzmechanismen erhalten bleiben.

Referenzverbraucher: Substanzpflege einschließlich Übersetzungen sowie die
Formulare für Unternehmen, Bewerbungen und Projekte.

### Sortierung

Clientseitige `ListView`-Tabellen und bestehende `SortableTable`-Verbraucher nutzen
`tableSorting` mit Tastatur-Buttons, Richtungspfeilen und `aria-sort`. Aktionsspalten
werden ausgelassen; weitere Ausnahmen können mit `data-no-sort` markiert werden.
Sortierung erfolgt auf allen geladenen Zeilen vor der clientseitigen Pagination.
Für serverseitige Listen stellt `SortHeader` (`sort-header`) einen Link mit Label,
Sortierrichtung und `aria-sort` bereit. Das jeweilige Repository sortiert den gesamten
Trefferbestand vor LIMIT/OFFSET; es darf nur erlaubte Spalten übernehmen. Die
Substanzlisten sind dafür der Referenzverbraucher.

Sortierindikatoren verwenden einheitlich die Unicode-Winkel `⌃` (aufsteigend) und `⌄` (absteigend); ohne aktive Sortierung erscheinen beide. Die Zeichen werden unabhängig von der Großschreibung der Spaltenüberschrift dargestellt.

### Gemeinsame Formular- und Listenaktionen

`CrudForm` verwendet `LinkButton` für Abbrechen. `RecordActions` nutzt dessen
`iconOnly`-Darstellung mit weiterhin benannten, tastaturbedienbaren Links.
`Pagination` verwendet `size="compact"` für Seitenaktionen und die gemeinsame
`select-field`-Klasse für die Seitengröße. Inaktive Seiten bleiben deaktivierte
Buttons beziehungsweise nicht fokussierbare Platzhalter; ausgeblendete
Seitennummern bleiben auch mit den gemeinsamen Button-Regeln verborgen.
Rahmen, Hover und Fokus kommen aus `controls.css` und den Theme-Variablen.
Die Komponenten behalten nur ihre jeweiligen Layout-Regeln.

### Einheitlicher Vertrag für Komponenten und native Formulare

Der Inhaltsbereich einer Anwendung kann `class="ui-controls"` verwenden und
`@hfanieng/ui/controls.css` sowie `@hfanieng/ui/tables.css` laden. Damit gelten
dieselben Regeln auch für native Astro- und Preact-Formulare, ohne deren
Validierung, Events oder Übermittlung umzubauen. Navigation und Druckdokumente
werden nicht automatisch in diesen Inhaltsbereich aufgenommen.

| Element | Gemeinsame Grundlage |
| --- | --- |
| Aktionen und Navigation | `ActionButton`, `LinkButton`, `.button` für Preact/native Steuerelemente |
| Text, Auswahl, mehrzeiliger Text | `TextField`, `SelectField`, `.text-field`, `.select-field`, `.shared-textarea` und native Felder in `.ui-controls` |
| Feldzustände | Fokus, deaktiviert, `aria-invalid`, Platzhalter; native Validierungsattribute bleiben erhalten |
| Checkbox und Radio | Eigene kompakte Maße, gemeinsame Akzent- und Fokusfarbe |
| Aufklappbereiche | Native `details` in `.ui-controls` oder explizit `.disclosure`; Unicode-Chevron und Tastaturfokus |
| Tabellen | `DataTable` und native Tabellen in `.ui-controls` verwenden `tables.css` |
| Meldungen und Leerzustände | `FlashMessageCenter`, `StatusBadge`, `EmptyState` verwenden semantische `--color-*`-Variablen |
| Seitennavigation und Datensatzaktionen | `Pagination`, `RecordActions` bauen auf den gemeinsamen Buttons auf |

`--control-background` und `--control-border` bestimmen die Feldoberflächen.
Die Compliance-Suite verwendet dafür ihre grauen Suchfeldfarben. Suchfelder und
Dropzone verwenden weiterhin `--color-search-background` und
`--color-search-border`. Die Defaults im UI-Paket bleiben unabhängig vom
Farbschema einer konkreten Anwendung. Versteckte Felder und Upload-Inputs werden
nicht durch die allgemeinen Textfeld-Regeln vergrößert.

`TextField` und `SelectField` unterstützen native HTML-Attribute wie `required`,
`disabled` und `aria-invalid`. Ein explizites `id` ermöglicht mehrere Felder mit
demselben Formularnamen. Hinweistext und `aria-describedby` werden verknüpft.
Lokale CSS-Regeln sollten fachliche Anordnung und Größenbedarf beschreiben;
Farben, Rahmen und Fokuszustände werden zentral über diesen Vertrag gepflegt.

Die Compliance-Komponenten `Tabs` und `SdsMarkdownReviewCarousel` verwenden für
ihre Preact-Steuerelemente dieselben Button- und Textarea-Klassen. Das Layout lädt
die gemeinsame CSS-Datei einmal; die Preact-Module bleiben auch ohne CSS-Loader
in Node testbar. `TranslationProposalStatus` verwendet das gemeinsame
`StatusBadge`. Fachliche Editor-Schrift und Höhe bleiben lokale Layoutangaben.

## 0.6.0 adoption

This version adds LinkButton, compact/icon button variants, the opt-in
`ui-controls` scope and the `tables.css` export. Form cancellation, pagination
and record actions use the same button styles. TextField and SelectField forward
native attributes. Semantic field tokens are `--control-background` and
`--control-border`; secondary action tokens are `--button-secondary-border` and
`--button-secondary-hover-background`.

Remove consumer CSS that overrides the internal buttons, pagination controls or
FilterBar anchors. Set semantic variables in the consumer theme instead.
For native forms/tables, add `ui-controls` to their content container and import
both controls.css and tables.css. Keep navigation/print documents outside that
scope unless intentionally adopting it. Existing form actions, permissions and
server validation remain consumer responsibilities.

The 0.6.0 archive is prepared locally; a public GitHub Release is a separate step.
After publication, consumers can use the immutable `ui-v0.6.0` release asset.
Do not rewrite older assets or silently replace consumers' 0.5.8 archives.

## 0.6.1: Preact CSS Modules

FlashMessageCenter verwendet eine mitgelieferte `.module.css`-Datei. Die internen
Styles von Compliance-Tabs und SDS-Editor sind ebenfalls in CSS Modules gekapselt.
Gemeinsame `.button`- und `.shared-textarea`-Klassen bleiben im zentralen Stylesheet.
Node-Verhaltenstests bilden ausschließlich CSS-Klassennamen ab; der separate
Astro-Paket-/Browsertest prüft die echte Vite-Kompilierung des ausgelieferten CSS.

### Prüfstand 26.09.2026

Die lokale Suite wurde für Substanzsuche, Phrasensuche, SDS-Upload und
Klassifizierung jeweils in Dark/Light und Desktop/Mobil geprüft (16 Kombinationen).
Bei Browser-Zoom 110 % lagen die gemessenen CSS-Viewportbreiten bei 1309 und 355 px.
Keine dieser Ansichten hatte horizontalen Dokumentüberlauf oder ein Astro-Fehleroverlay;
Hintergrund und Text wechselten in beiden Themes. Breite Tabellen scrollen intern.
Die Theme- und Viewport-Overrides wurden danach zurückgesetzt.
Dies ist eine repräsentative Prüfung der gemeinsamen Oberflächen, keine vollständige
Prüfung aller fachlichen Datenzustände. Die lokale Messmatrix liegt unter
`.local/ui-review/matrix.json` und wird nicht mit dem Paket ausgeliefert.

Validierung: 99 Anwendungstests, 9 Compliance-UI-Verhaltenstests, Astro/TypeScript,
Produktionsbuild und unabhängiger Paket-Browsertest. Die Übernahme in andere
Repositories erfolgt separat durch den jeweiligen Projektstand.

## Durchsuchbare Auswahlen in bestehenden Formularen

`@hfanieng/ui/searchable-select-enhancement` aktiviert dieselbe Suchoberfläche
wie `SearchableSelect` für vorhandene Einfachauswahlen. Einmal im Layout einsetzen:

```astro
---
import SearchableSelectEnhancement from '@hfanieng/ui/searchable-select-enhancement';
---
<main class="ui-controls"><slot /></main>
<SearchableSelectEnhancement />
```

Der Standardselektor ist `.ui-controls select`; über `selector` lässt er sich
auf einen anderen Bereich begrenzen. Lokale Listen zeigen beim Öffnen alle
verfügbaren Optionen und filtern ab dem ersten Zeichen nach Beschriftung oder
Wert. Remote-Suchen behalten ihre Mindestlänge und Begrenzung.

Das native Feld bleibt für Formularwerte, Pflichtprüfung, Vorbelegung, Reset
und `input`-/`change`-Listener erhalten. Ohne JavaScript bleibt es bedienbar.
Die Ergänzung verschiebt keine frameworkverwalteten Knoten; neu eingefügte
Preact-Zeilen werden automatisch erfasst und entfernte Ansichten aufgeräumt.
Mehrfachauswahlen und Listenfelder (`multiple` bzw. `size > 1`) werden nicht
in Einfachauswahlen umgewandelt. Die interne Suite verwendet solche Felder derzeit nicht.

Die Auswahlliste nutzt die Popover-Ebene, damit Tabellen sie nicht abschneiden.
Geprüft werden auch Pflichtprüfung, Formularwerte, Reset, deaktivierte Optionen,
Tastaturauswahl, dynamische Preact-Zeilen und mobile Begrenzung im Paket-Browsertest.

### Gemeinsamer Lebenszyklus der Suchauswahl

Direkte `SearchableSelect`-Komponenten und automatisch ergänzte Felder verwenden
nun denselben nativen `select` als Formularquelle und dieselbe DOM-Factory für
Trigger, Suchfeld und Trefferliste. Die direkte Komponente unterstützt ebenfalls
`required` und `disabled`; vorbelegte Werte bleiben auch ohne geladenes Suchergebnis
erhalten. Ohne JavaScript stehen die serverseitig gelieferten Optionen zur Verfügung.

`searchableSelectLifecycle.ts` initialisiert jeden Quellknoten einmal. Die automatische
Ergänzung beobachtet standardmäßig `.ui-controls` (mit `scope` anpassbar), verarbeitet
nur hinzugefügte und entfernte Zweige und ignoriert ihre eigene Suchoberfläche.
Direkte Komponenten außerhalb der Suite werden in ihrem Formular-/Main-Bereich erfasst.
Änderungen an Optionen beobachtet ausschließlich die jeweilige Auswahl.
Programmatische Änderungen am ausgewählten Wert müssen wie bei nativen Formularen
ein `change`-Event auslösen, damit die Anzeige synchronisiert wird.

Beim Entfernen und vor Astro-Seitenwechseln werden Listener, Observer, ausstehende
Suchanfragen und Timer beendet sowie ursprüngliche Fokus-/ARIA-Attribute wiederhergestellt.
Formular-Reset stellt den vorbelegten Wert und die Beschriftung wieder her.
Die Paket-Browsertests prüfen beide Einbindungsarten einschließlich dynamischer Zeilen,
Reset/Pflichtprüfung und erneutem Einhängen nach einem Seitenwechsel.


### Listenmarker und Nach-oben-Navigation

`@hfanieng/ui/list-markers.css` einmal im Anwendungslayout laden. Ungeordnete
Inhaltslisten und Tabellenzeilen erhalten keine dekorativen Rechteckmarker.
Nummerierte Listen behalten ihre Reihenfolge; CRUD-Icons bleiben separate Aktionen.
Navigation und Bedienelemente einschließlich Pagination, Seitenzahlen und
Vor/Zurück erhalten keine Inhaltsmarker. Die Sidebar einschließlich
mobiler Hauptnavigation behält ihre bestehenden senkrechten Linien, Abstände
und Aktivmarkierungen.

`BackToTop` aus `@hfanieng/ui/back-to-top` einmal pro Layout einbinden.
Optionales `label` ermöglicht Übersetzungen. Der Button erscheint unten rechts,
sobald die Seite gescrollt wurde; Inhalts- und Größenänderungen werden berücksichtigt.
Reduzierte Bewegung wird respektiert; am Seitenanfang wird der Button ausgeblendet.


### TreeList: Tabelle mit Baumhierarchie

`@hfanieng/ui/tree-list` erweitert `DataTable` um beliebig tief verschachtelte
Zeilen, zugängliche Aufklapp-Buttons und optionale Checkboxen. Die bestehenden
Tabellen- und Theme-Styles einschließlich Darkmode-Zeilenstreifen werden verwendet.
Die Einbindung in `ListView` erfolgt über dessen `table`-Slot; Pagination und
Sortierung werden für den Baum nicht automatisch aktiviert.

Props: eindeutige Instanz-`id`, `label`, `columns`, `nodes`, optional `expanded`
(Standard: true) und `checkboxes` (`status`, `selection`, `none`). Jeder Knoten
braucht eine innerhalb der Instanz eindeutige `id` und `label`; optional sind
`cells` (Werte der Folgespalten, Zeilenumbrüche möglich), `children`, `checked`,
`note` und `details` (aufklappbarer Text in der letzten Spalte).

Im Statusmodus bleiben Checkboxen unveränderbar; ein Elternknoten ist markiert,
wenn er selbst oder ein Nachkomme markiert ist. Im Auswahlmodus wird eine Auswahl
an Nachkommen weitergegeben; Eltern zeigen Teilselektion als indeterminate an.
Änderungen lösen `tree-list:selection-change` mit `detail.selected` (Knoten-IDs)
aus. Auswahl ist lokal und wird nicht gespeichert. Beim Einklappen eines Eltern-
knotens bleiben die Aufklappzustände der Untergruppen erhalten. Fachliche
Bedeutung, Datenquelle und Persistierung liegen beim Consumer.

### Appearance selection

Use `@hfanieng/ui/theme-setup` once in the document head and
`@hfanieng/ui/theme-select` in the header. Both public and internal pages offer
light, dark and system appearance. The setting is kept in Local Storage and a
one-year `theme` cookie; on fanieng.com the cookie also covers subdomains.
Existing `theme` and `compliance-theme` Local Storage values are migration
fallbacks. Internal layouts may enable their existing `?theme=light|dark`
override with `allowUrlOverride`. The selector provides German and English defaults;
`labels` can supply the select label and the three option labels for other languages.

### Editorial cards and disclosures

`OverviewCard` supports `variant="summary"` for editorial content, with optional
`headingLevel={2|3|4}` (default 3), `titleId`, `class`, an `eyebrow` slot and the
existing `actions` slot. Metric/value behavior and defaults remain unchanged.
Use shared `TagList` for topic lists instead of local card-specific tag markup.

`@hfanieng/ui/disclosure` provides native `details`/`summary` with `title`, optional
`eyebrow`, `id`, `open` and `class`. An explicit `id` links the summary to its content.
Für Tabellenzellen stehen `compact` (ohne umgebende Card) und
`chevronPosition="start"` (Pfeil vor dem Titel) zur Verfügung. Native
Tastaturbedienung, Fokus und die gemeinsame Mindesthöhe bleiben erhalten.
`@hfanieng/ui/disclosure-group` groups sections; `aria-label` supplies an accessible
group name. The chevron uses the shared icon component. Keyboard interaction is
native (Enter/Space), each section opens independently, and motion respects the
reduced-motion preference. Shared tokens own borders, surface, focus and spacing.


`DataTable` bietet optional `filterActions` für Lucide-Filter-/Zurücksetzen-Aktionen
mit ARIA-Labels und Tooltips. `scrollable` begrenzt den eigenen Scrollbereich
(Standard: 60vh, anpassbar über `--data-table-max-height`), hält Spaltenköpfe sowie
die Aktionsspalte sichtbar und macht den Bereich per Tastatur erreichbar.
Bestehende Tabellen bleiben ohne diese Optionen unverändert.

Mit `filterLabelsAsPlaceholders` stehen Filterbeschriftungen als Platzhalter im
Suchfeld; die zugehörigen Labels bleiben für Screenreader erhalten.

### Ergänzende Filteraktionen

`FilterBar` unterstützt `iconActions` für die gemeinsamen Filter-/Reset-Icons.
Der benannte Slot `actions` ergänzt weitere Aktionen direkt nach Zurücksetzen,
z. B. den zentralen `CopyButton`. Die aufrufende Liste übergibt den vollständigen
gefilterten Export über alle Ergebnisseiten; Tooltip und ARIA-Label benennen
Datensatz und Umfang. Clipboard und Flash-Rückmeldung bleiben im `CopyButton`.
Für Markdown-Ausgaben wählt `format="markdown"` das zentrale Icon
`copy-markdown` (Lucide `FileCode`). Standardmäßig verwendet der Button `Copy`.
