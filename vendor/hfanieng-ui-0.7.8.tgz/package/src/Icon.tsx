/** @jsxImportSource preact */
/** @jsxRuntime automatic */
import {
  BookOpen, Check, ChevronDown, ChevronLeft, ChevronRight, ChevronUp, Copy, Download, Eye, FileText, FileCheck, FileCode, FileExclamationPoint, FileX, FileQuestionMark,
  FlaskRound, Folder, Gauge, Globe, House, Languages, LogOut, Mail, Menu, Moon, Pencil, Plus,
  Search, Filter, RotateCcw, Undo2, Save, ShieldCheck, ShieldPlus, Sun, Tag, Trash2, UserRound, Workflow, X,
} from 'lucide-preact';
import BrandIcon, { type BrandIconName, isBrandIcon } from './BrandIcon.tsx';

// Fachliche Namen bleiben stabil; die konkrete Lucide-Auswahl wird nur hier gepflegt.
const icons = {
  'evidence-supported': FileCheck, 'evidence-review': FileExclamationPoint, 'evidence-missing': FileX, 'evidence-unknown': FileQuestionMark,
  home: House, projects: Folder, knowledge: BookOpen, processes: Workflow,
  about: UserRound, contact: Mail, cockpit: Gauge, admin: ShieldCheck,
  compliance: ShieldPlus, skills: ShieldCheck, document: FileText, catalog: BookOpen,
  import: Download, search: Search, filter: Filter, reset: RotateCcw, sds: FileText, label: Tag, account: UserRound,
  user: UserRound, 'user-round': UserRound, logout: LogOut, menu: Menu, close: X,
  sun: Sun, moon: Moon, 'chevron-down': ChevronDown, 'chevron-left': ChevronLeft, 'chevron-right': ChevronRight,
  'chevron-up': ChevronUp, view: Eye, edit: Pencil, delete: Trash2, plus: Plus,
  review: FlaskRound, 'flask-round': FlaskRound, copy: Copy, save: Save, languages: Languages, globe: Globe, adopt: Check, undo: Undo2,
  'copy-markdown': FileCode,
} as const;

export type IconName = keyof typeof icons | BrandIconName;
export interface IconProps { name: IconName; size?: number; label?: string; class?: string; }

// Astro und Preact nutzen dieselbe Komponente, Geometrie und Strichstärke.
// Unbeschriftete Icons sind dekorativ; der Link/Button trägt dann das ARIA-Label.
export default function Icon({ name, size = 20, label, class: className }: IconProps) {
  if (isBrandIcon(name)) return <BrandIcon name={name} size={size} label={label} class={className} />;
  const Symbol = icons[name];
  return <Symbol size={size} strokeWidth={2} class={className}
    aria-hidden={label ? undefined : true} aria-label={label}
    role={label ? 'img' : undefined} focusable="false" />;
}
