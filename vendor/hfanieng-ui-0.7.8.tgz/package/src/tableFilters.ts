export const MIN_FILTER_CHARACTERS = 3;
const normalize = (value: string) => value.normalize('NFKC').toLocaleLowerCase('de').trim();

export function isActiveColumnFilter(query: string, minimum = MIN_FILTER_CHARACTERS): boolean {
  return (normalize(query).match(/[\p{L}\p{N}]/gu) ?? []).length >= minimum;
}

export function matchesColumnFilter(value: string, query: string, mode: 'phrase' | 'terms' = 'phrase', minimum = MIN_FILTER_CHARACTERS): boolean {
  if (!isActiveColumnFilter(query, minimum)) return true;
  const text = normalize(value);
  const needle = normalize(query);
  return mode === 'terms' ? needle.split(/\s+/u).every(term => text.includes(term)) : text.includes(needle);
}

export function tableRowFilterText(row: HTMLTableRowElement, column: number, scope: 'column' | 'row' = 'column'): string {
  return scope === 'row'
    ? [...row.cells].filter(cell => !cell.classList.contains('data-table__actions')).map(cell => cell.textContent ?? '').join(' ')
    : row.cells[column]?.textContent ?? '';
}

/** Operates on rendered rows, including rows added later by API clients. */
export function initializeTableFilters(container: HTMLElement) {
  if (container.dataset.filtersReady) return;
  const table = container.querySelector('table');
  const inputs = [...container.querySelectorAll<HTMLInputElement>('[data-column-filter]')];
  if (!table || !inputs.length) return;
  container.dataset.filtersReady = 'true';
  const summary = container.querySelector<HTMLElement>('[data-table-filter-summary]');
  const apply = () => {
    const rows = [...table.tBodies].flatMap(body => [...body.rows]);
    let visible = 0;
    for (const row of rows) {
      const matches = inputs.every(input => matchesColumnFilter(tableRowFilterText(row, Number(input.dataset.columnFilter), input.dataset.filterScope === 'row' ? 'row' : 'column'), input.value, input.dataset.filterMode === 'terms' ? 'terms' : 'phrase', Number(input.dataset.filterMin) || MIN_FILTER_CHARACTERS));
      row.dataset.filterExcluded = String(!matches);
      row.hidden = !matches;
      if (matches) visible++;
    }
    if (summary) summary.textContent = `${visible} von ${rows.length} Einträgen angezeigt.`;
    const empty = container.closest('[data-list-view]')?.querySelector<HTMLElement>('[data-list-empty]');
    if (empty) empty.hidden = visible > 0;
    container.dispatchEvent(new CustomEvent('table-filter-change', { bubbles: true, detail: { visible, total: rows.length } }));
  };
  inputs.forEach(input => input.addEventListener('input', apply));
  container.querySelector('[data-table-filter-apply]')?.addEventListener('click', apply);
  container.querySelector('[data-table-filter-reset]')?.addEventListener('click', () => {
    inputs.forEach(input => { input.value = ''; });
    apply();
    inputs[0]?.focus();
  });
  // Observe contents only: toggling row.hidden must not trigger another update.
  const observer = new MutationObserver(apply);
  observer.observe(table, { childList: true, subtree: true, characterData: true });
  apply();
  document.addEventListener('astro:before-swap', () => observer.disconnect(), { once: true });
}
