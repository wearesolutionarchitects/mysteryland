/** Sort all rendered rows before client pagination. Server tables use SortHeader links. */
export function initializeTableSorting(container: HTMLElement) {
  const table = container.querySelector('table');
  if (!table || table.dataset.sortableReady) return;
  table.dataset.sortableReady = 'true';
  let activeSort: { index: number; ascending: boolean } | undefined;
  const apply = () => {
    const body = table.tBodies[0];
    if (!body || !activeSort) return;
    const { index, ascending } = activeSort;
    [...body.rows].sort((a, b) => (a.cells[index]?.dataset.sortValue ?? a.cells[index]?.textContent ?? '').trim().localeCompare((b.cells[index]?.dataset.sortValue ?? b.cells[index]?.textContent ?? '').trim(), 'de', { numeric:true, sensitivity:'base' }) * (ascending ? 1 : -1)).forEach(row => body.append(row));
  };
  container.addEventListener('table-rows-change', () => {
    apply();
    container.dispatchEvent(new CustomEvent('table-sort-change', { bubbles: true }));
  });
  table.querySelectorAll<HTMLTableCellElement>('thead th').forEach((header, index) => {
    if (header.querySelector('a, button') || header.hasAttribute('data-no-sort') || /^Aktion(en)?$/i.test(header.textContent?.trim() ?? '')) return;
    const label = header.textContent?.trim() ?? '';
    const button = document.createElement('button');
    button.type = 'button'; button.className = 'table-sort';
    button.append(document.createTextNode(label));
    const indicator = document.createElement('span');
    indicator.className = 'table-sort__indicator'; indicator.setAttribute('aria-hidden', 'true');
    indicator.textContent = '⌃ ⌄'; button.append(indicator);
    button.setAttribute('aria-label', `${label}: aufsteigend sortieren`);
    header.replaceChildren(button); header.setAttribute('aria-sort', 'none');
    button.addEventListener('click', () => {
      const body = table.tBodies[0]; if (!body) return;
      const ascending = header.getAttribute('aria-sort') !== 'ascending';
      table.querySelectorAll('thead th[aria-sort]').forEach(cell => {
        cell.setAttribute('aria-sort', 'none');
        const icon = cell.querySelector('.table-sort__indicator'); if (icon) icon.textContent = '⌃ ⌄';
        const control = cell.querySelector('button');
        if (control) control.setAttribute('aria-label', `${control.firstChild?.textContent}: aufsteigend sortieren`);
      });
      header.setAttribute('aria-sort', ascending ? 'ascending' : 'descending');
      indicator.textContent = ascending ? '⌃' : '⌄';
      button.setAttribute('aria-label', `${label}: ${ascending ? 'absteigend' : 'aufsteigend'} sortieren`);
      activeSort = { index, ascending };
      apply();
      container.dispatchEvent(new CustomEvent('table-sort-change', { bubbles:true }));
    });
  });
}
