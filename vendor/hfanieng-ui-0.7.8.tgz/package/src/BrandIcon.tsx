/** @jsxImportSource preact */
/** @jsxRuntime automatic */
// Markenlogos sind keine UI-Piktogramme. Lucide v1 führt keine Markenlogos mehr.
// Vorhandene Logos bleiben hier zentral erhalten; keine lokalen SVG-Kopien anlegen.
const brands = {
  github: <><path d="M9 19c-5 1.5-5-2.5-7-3" /><path d="M15 22v-3.9a3.4 3.4 0 0 0-.95-2.65c3.15-.35 6.45-1.55 6.45-7A5.45 5.45 0 0 0 19 4.7 5.1 5.1 0 0 0 18.9 1S17.7.65 15 2.48a13.4 13.4 0 0 0-7 0C5.3.65 4.1 1 4.1 1A5.1 5.1 0 0 0 4 4.7a5.45 5.45 0 0 0-1.5 3.78c0 5.42 3.3 6.62 6.45 7A3.4 3.4 0 0 0 8 18.1V22" /></>,
  discord: <><path d="M8 9.5h.01" /><path d="M16 9.5h.01" /><path d="M8.5 15c2.3 1.2 4.7 1.2 7 0" /><path d="M7 4.5c3.2-1 6.8-1 10 0 2 3 2.7 6.2 2 10-2.3 1.7-4.7 2.5-7 2.5s-4.7-.8-7-2.5c-.7-3.8 0-7 2-10Z" /></>,
  linkedin: <><path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-4 0v7h-4V9h4v2" /><path d="M2 9h4v12H2z" /><circle cx="4" cy="4" r="2" /></>,
  twitch: <><path d="M4 3h16v11l-4 4h-4l-3 3v-3H4z" /><path d="M9 8v4" /><path d="M15 8v4" /></>,
  youtube: <><path d="M22 12s0-3.3-.42-4.75a3 3 0 0 0-2.12-2.12C17.99 4.75 12 4.75 12 4.75s-5.99 0-7.46.38a3 3 0 0 0-2.12 2.12C2 8.7 2 12 2 12s0 3.3.42 4.75a3 3 0 0 0 2.12 2.12c1.47.38 7.46.38 7.46.38s5.99 0 7.46-.38a3 3 0 0 0 2.12-2.12C22 15.3 22 12 22 12Z" /><path d="m10 15 5-3-5-3z" /></>,
  instagram: <><rect x="3" y="3" width="18" height="18" rx="5" /><circle cx="12" cy="12" r="4" /><path d="M17.5 6.5h.01" /></>,
  facebook: <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z" />,
} as const;
export type BrandIconName = keyof typeof brands;
export const isBrandIcon = (name: string): name is BrandIconName => Object.hasOwn(brands, name);
export default function BrandIcon({name, size, label, class: className}: {name: BrandIconName; size: number; label?: string; class?: string}) {
  return <svg class={className} width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width={2} stroke-linecap="round" stroke-linejoin="round" aria-hidden={label ? undefined : true} aria-label={label} role={label ? 'img' : undefined} focusable="false">{brands[name]}</svg>;
}
