import type { Plugin } from 'vite';

/** Forward displayed browser feedback to the development terminal. */
export function flashMessageVitePlugin(): Plugin {
  return {
    name: 'ui-flash-message-log',
    apply: 'serve',
    configureServer(server) {
      server.ws.on('ui:flash-log', (payload: unknown) => {
        if (!payload || typeof payload !== 'object') return;
        const { message, variant, path } = payload as Record<string, unknown>;
        if (typeof message !== 'string' || !message.trim()) return;
        if (variant !== 'success' && variant !== 'information' && variant !== 'error') return;
        if (typeof path !== 'string' || !path.startsWith('/')) return;
        const line = `[flash:${variant}] ${JSON.stringify({ message, path })}`;
        const level = variant === 'error' ? 'error' : 'info';
        server.config.logger[level](line, { timestamp: true });
      });
    },
  };
}
