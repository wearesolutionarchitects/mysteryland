/** Abbrechen schließt auch bei reiner Fragmentnavigation den Dialog, ohne einen POST zu wiederholen. */
export function navigateDialogReturn(dialog: HTMLDialogElement, href: string): void {
  dialog.close();
  window.location.assign(href);
}

export function bindDialogReturnLinks(dialog: HTMLDialogElement, href: string): void {
  const target = new URL(href, window.location.href).href;
  dialog.querySelectorAll<HTMLAnchorElement>('a[href]').forEach(link => {
    if (link.href !== target) return;
    link.addEventListener('click', event => {
      event.preventDefault();
      navigateDialogReturn(dialog, href);
    });
  });
}
