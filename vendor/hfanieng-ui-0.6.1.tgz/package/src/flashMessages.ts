export type FlashMessageVariant = 'success' | 'information' | 'error';

export interface FlashMessageDetail {
  message: string;
  variant?: FlashMessageVariant;
  /** 0 keeps the message visible until dismissed. */
  durationMs?: number;
}

export const FLASH_MESSAGE_EVENT = 'compliance-ui:flash-message';
let subscribers = 0;
const buffered: FlashMessageDetail[] = [];

/** Retain early page-load feedback until the shared center has hydrated. */
export const subscribeFlashMessages = (show: (detail: FlashMessageDetail) => void): (() => void) => {
  const listener = (event: Event) => show((event as CustomEvent<FlashMessageDetail>).detail);
  subscribers++;
  window.addEventListener(FLASH_MESSAGE_EVENT, listener);
  buffered.splice(0).forEach(show);
  return () => { subscribers--; window.removeEventListener(FLASH_MESSAGE_EVENT, listener); };
};

const PENDING_FLASH_MESSAGE_KEY = 'compliance-ui:pending-flash-message';

export const showFlashMessage = (
  message: string,
  variant: FlashMessageVariant = 'information',
  persistOnReload = false,
  durationMs = 4200,
): void => {
  if (persistOnReload) {
    try {
      sessionStorage.setItem(PENDING_FLASH_MESSAGE_KEY, JSON.stringify({ message, variant, durationMs } satisfies FlashMessageDetail));
    } catch {
      // Storage can be unavailable in privacy-restricted browser contexts.
    }
  }
  if (!subscribers && !persistOnReload) {
    buffered.push({ message, variant, durationMs });
    return;
  }
  window.dispatchEvent(new CustomEvent<FlashMessageDetail>(FLASH_MESSAGE_EVENT, {
    detail: { message, variant, durationMs },
  }));
};

export const consumePendingFlashMessage = (): FlashMessageDetail | undefined => {
  try {
    const raw = sessionStorage.getItem(PENDING_FLASH_MESSAGE_KEY);
    if (!raw) return undefined;
    sessionStorage.removeItem(PENDING_FLASH_MESSAGE_KEY);
    const detail = JSON.parse(raw) as FlashMessageDetail;
    return detail?.message ? detail : undefined;
  } catch {
    return undefined;
  }
};
