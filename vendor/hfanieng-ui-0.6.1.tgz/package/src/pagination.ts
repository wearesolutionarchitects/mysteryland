export const DEFAULT_PAGE_SIZE = 25;
export const PAGE_SIZE_OPTIONS = [25, 50, 100] as const;
export function normalizePageSize(value: unknown): number {
  const size = Number(value);
  return PAGE_SIZE_OPTIONS.some(option => option === size) ? size : DEFAULT_PAGE_SIZE;
}
export function paginationRange(page: number, pageSize: number, count: number, total?: number): string {
  const start = count ? (page - 1) * pageSize + 1 : 0;
  const end = count ? start + count - 1 : 0;
  return `${start}–${end}${total === undefined ? '' : ` von ${total}`}`;
}
