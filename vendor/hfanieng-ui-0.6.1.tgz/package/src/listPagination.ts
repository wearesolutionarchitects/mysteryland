import { normalizePageSize, paginationRange } from './pagination.ts';

/** Client lists paginate all matching rows; server lists supply their own pagination slot. */
export function initializeListPagination(list: HTMLElement) {
  const navigation = list.querySelector<HTMLElement>('[data-pagination][data-client]');
  const table = list.querySelector('table');
  if (!navigation || !table || navigation.dataset.ready) return;
  navigation.dataset.ready = 'true';
  const selector = navigation.querySelector<HTMLSelectElement>('[data-page-size]')!;
  const previous = navigation.querySelector<HTMLButtonElement>('[data-page-previous]')!;
  const next = navigation.querySelector<HTMLButtonElement>('[data-page-next]')!;
  let page = 1;
  const render = () => {
    const size = normalizePageSize(selector.value);
    const rows = [...table.tBodies].flatMap(body => [...body.rows]);
    const matches = rows.filter(row => row.dataset.filterExcluded !== 'true');
    page = Math.min(page, Math.max(1, Math.ceil(matches.length / size)));
    rows.forEach(row => { row.hidden = true; });
    const visible = matches.slice((page - 1) * size, page * size);
    visible.forEach(row => { row.hidden = false; });
    navigation.querySelector('[data-page-range]')!.textContent = paginationRange(page, size, visible.length, matches.length);
    navigation.dataset.page = String(page);
    const current = navigation.querySelector<HTMLElement>('[data-page-current]');
    if (current) {
      current.textContent = String(page);
      current.setAttribute('aria-label', `Seite ${page}`);
    }
    for (const [attribute, target, available] of [
      ['data-page-number-previous', page - 1, page > 1],
      ['data-page-number-next', page + 1, page * size < matches.length],
    ] as const) {
      const button = navigation.querySelector<HTMLButtonElement>(`[${attribute}]`);
      if (button) {
        button.hidden = !available;
        button.textContent = String(target);
        button.setAttribute('aria-label', `Seite ${target}`);
      }
    }
    previous.disabled = page <= 1;
    next.disabled = page * size >= matches.length;
    const empty = list.querySelector<HTMLElement>('[data-list-empty]');
    if (empty) empty.hidden = matches.length > 0;
  };
  selector.addEventListener('change', () => { page = 1; render(); });
  navigation.querySelector('form')?.addEventListener('submit', event => event.preventDefault());
  previous.addEventListener('click', () => { page--; render(); });
  next.addEventListener('click', () => { page++; render(); });
  navigation.querySelector('[data-page-number-previous]')?.addEventListener('click', () => previous.click());
  navigation.querySelector('[data-page-number-next]')?.addEventListener('click', () => next.click());
  list.addEventListener('table-sort-change', () => { page = 1; render(); });
  list.addEventListener('table-filter-change', () => { page = 1; render(); });
  const observer = new MutationObserver(render);
  observer.observe(table, { childList: true, subtree: true, characterData: true });
  document.addEventListener('astro:before-swap', () => observer.disconnect(), { once: true });
  render();
}
