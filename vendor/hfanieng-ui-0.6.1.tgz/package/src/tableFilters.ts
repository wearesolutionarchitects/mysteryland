export const MIN_FILTER_CHARACTERS = 3;
const normalize = (value: string) => value.normalize('NFKC').toLocaleLowerCase('de').trim();

export function isActiveColumnFilter(query: string): boolean {
  return (normalize(query).match(/[\p{L}\p{N}]/gu) ?? []).length >= MIN_FILTER_CHARACTERS;
}

export function matchesColumnFilter(value: string, query: string): boolean {
  return !isActiveColumnFilter(query) || normalize(value).includes(normalize(query));
}

/** Operates on rendered rows, including rows added later by API clients. */
export function initializeTableFilters(container: HTMLElement) {
  if (container.dataset.filtersReady) return;
  const table = container.querySelector('table');
  const inputs = [...container.querySelectorAll<HTMLInputElement>('[data-column-filter]')];
  if (!table || !inputs.length) return;
  container.dataset.filtersReady = 'true';
  const summary = container.querySelector<HTMLElement>('[data-table-filter-summary]');
  const apply = () => {
    const rows = [...table.tBodies].flatMap(body => [...body.rows]);
    let visible = 0;
    for (const row of rows) {
      const matches = inputs.every(input => matchesColumnFilter(row.cells[Number(input.dataset.columnFilter)]?.textContent ?? '', input.value));
      row.dataset.filterExcluded = String(!matches);
      row.hidden = !matches;
      if (matches) visible++;
    }
    if (summary) summary.textContent = `${visible} von ${rows.length} Einträgen angezeigt.`;
    const empty = container.closest('[data-list-view]')?.querySelector<HTMLElement>('[data-list-empty]');
    if (empty) empty.hidden = visible > 0;
    container.dispatchEvent(new CustomEvent('table-filter-change', { bubbles: true, detail: { visible, total: rows.length } }));
  };
  inputs.forEach(input => input.addEventListener('input', apply));
  // Observe contents only: toggling row.hidden must not trigger another update.
  const observer = new MutationObserver(apply);
  observer.observe(table, { childList: true, subtree: true, characterData: true });
  apply();
  document.addEventListener('astro:before-swap', () => observer.disconnect(), { once: true });
}
