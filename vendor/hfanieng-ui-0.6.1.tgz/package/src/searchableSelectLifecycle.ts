import { initializeSearchableSelect } from './searchableSelect';

const entries = new Map<HTMLSelectElement, { root: HTMLElement; owned: boolean; dispose: () => void }>();
const observers: MutationObserver[] = [];
let started = false;

function selectNodes(node: Node): HTMLSelectElement[] {
  if (!(node instanceof Element)) return [];
  // Changes to result buttons or other generated UI never concern source fields.
  if (node.closest('.searchable-select__panel, .searchable-select__trigger')) return [];
  return [...(node instanceof HTMLSelectElement ? [node] : []), ...node.querySelectorAll<HTMLSelectElement>('select')];
}

function enhance(select: HTMLSelectElement) {
  if (entries.has(select) || select.multiple || select.size > 1) return;
  const direct = select.closest<HTMLElement>('[data-searchable-select]');
  const root = direct ?? document.createElement('div');
  if (!direct) {
    root.className = 'searchable-select searchable-select--native';
    root.dataset.minQueryLength = '0';
    select.after(root);
  }
  const dispose = initializeSearchableSelect(root, select);
  if (dispose) entries.set(select, { root, owned: !direct, dispose });
}

function stop() {
  observers.splice(0).forEach(observer => observer.disconnect());
  for (const { root, owned, dispose } of entries.values()) {
    dispose();
    if (owned) root.remove();
  }
  entries.clear();
}

function mount() {
  stop();
  const scopes = new Map<Element, Set<string>>();
  const addScope = (scope: Element, selector: string) => {
    if (!scopes.has(scope)) scopes.set(scope, new Set());
    scopes.get(scope)!.add(selector);
  };
  document.querySelectorAll<HTMLElement>('[data-searchable-select-scope]').forEach(marker => {
    document.querySelectorAll(marker.dataset.searchableSelectScope!).forEach(scope => {
      addScope(scope, marker.dataset.searchableSelectSelector || 'select');
    });
  });
  document.querySelectorAll<HTMLElement>('[data-searchable-select]').forEach(root => {
    // Also support direct components outside the suite (e.g. an isolated form).
    const scope = root.closest('main, form') ?? root.parentElement!;
    if (![...scopes.keys()].some(existing => existing.contains(root))) addScope(scope, '[data-searchable-select] select');
  });
  for (const [scope, selectors] of scopes) {
    const eligible = (select: HTMLSelectElement) => select.closest('[data-searchable-select]') || [...selectors].some(selector => select.matches(selector));
    const visit = (node: Node) => selectNodes(node).filter(select => eligible(select)).forEach(enhance);
    visit(scope);
    const observer = new MutationObserver(records => {
      const removed = new Set<HTMLSelectElement>();
      for (const record of records) {
        // Only inspect added/removed branches, not all fields for every DOM change.
        record.addedNodes.forEach(visit);
        record.removedNodes.forEach(node => selectNodes(node).forEach(select => removed.add(select)));
      }
      for (const select of removed) {
        if (select.isConnected) continue; // Framework move, not removal.
        const entry = entries.get(select);
        if (entry) {
          entry.dispose();
          if (entry.owned) entry.root.remove();
          entries.delete(select);
        }
      }
    });
    observer.observe(scope, { subtree: true, childList: true });
    observers.push(observer);
  }
}

export function startSearchableSelects() {
  if (started) return;
  started = true;
  mount();
  document.addEventListener('astro:before-swap', stop);
  document.addEventListener('astro:page-load', mount);
}
