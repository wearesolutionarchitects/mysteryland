/** @jsxImportSource preact */
import styles from './FlashMessageCenter.module.css';
import { useEffect, useState } from 'preact/hooks';

import {
  subscribeFlashMessages,
  consumePendingFlashMessage,
  type FlashMessageDetail,
  type FlashMessageVariant,
} from './flashMessages.ts';

interface VisibleFlashMessage {
  id: number;
  message: string;
  variant: FlashMessageVariant;
}

export function FlashMessageCenter() {
  const [messages, setMessages] = useState<VisibleFlashMessage[]>([]);

  useEffect(() => {
    let nextId = 0;
    const show = (detail: FlashMessageDetail | undefined) => {
      if (!detail?.message) return;
      const id = ++nextId;
      setMessages((current) => [...current, {
        id,
        message: detail.message,
        variant: detail.variant ?? 'information',
      }]);
      if (detail.durationMs !== 0) window.setTimeout(() => {
        setMessages((current) => current.filter((message) => message.id !== id));
      }, detail.durationMs ?? 4200);
    };
    const unsubscribe = subscribeFlashMessages(show);
    show(consumePendingFlashMessage());
    return unsubscribe;
  }, []);

  return (
    <aside class={styles['compliance-flash-center']} aria-label="Statusmeldungen" aria-live="polite">
      {messages.map((message) => (
        <div
          key={message.id}
          class={`${styles['compliance-flash']} ${styles[`compliance-flash--${message.variant}`] ?? ''}`}
          role={message.variant === 'error' ? 'alert' : 'status'}
        >
          {message.message}
          <button class="button button--secondary button--compact" type="button" aria-label="Meldung schließen" onClick={() =>
            setMessages(current => current.filter(item => item.id !== message.id))}>×</button>
        </div>
      ))}

    </aside>
  );
}
