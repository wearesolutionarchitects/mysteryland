const formatBytes = (bytes: number): string => {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 ** 2) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / 1024 ** 2).toFixed(1)} MB`;
};

const matchesAcceptToken = (file: File, token: string): boolean => {
  const normalized = token.trim().toLowerCase();
  if (normalized === '') return false;
  if (normalized.startsWith('.')) return file.name.toLowerCase().endsWith(normalized);
  if (normalized.endsWith('/*')) return file.type.toLowerCase().startsWith(normalized.slice(0, -1));
  return file.type.toLowerCase() === normalized;
};

const validateFile = (dropzone: HTMLElement, file: File): string | undefined => {
  const accept = dropzone.dataset.accept?.split(',').filter(Boolean) ?? [];
  if (accept.length > 0 && !accept.some((token) => matchesAcceptToken(file, token))) {
    return `Bitte eine Datei im erlaubten Format auswählen: ${accept.join(', ')}.`;
  }

  const maximumFileSize = Number(dropzone.dataset.maximumFileSize || 0);
  if (maximumFileSize > 0 && file.size > maximumFileSize) {
    return `Die Datei ist größer als ${formatBytes(maximumFileSize)}.`;
  }

  return undefined;
};

const updateDropzone = (dropzone: HTMLElement): void => {
  const input = dropzone.querySelector<HTMLInputElement>('[data-file-input]');
  const name = dropzone.querySelector<HTMLElement>('[data-file-name]');
  const status = dropzone.querySelector<HTMLElement>('[data-file-status]');
  const emptyLabel = dropzone.dataset.emptyLabel || 'Keine Datei ausgewählt';
  const file = input?.files?.[0];

  if (!input || !name || !status) return;
  if (!file) {
    input.setCustomValidity('');
    name.textContent = emptyLabel;
    name.dataset.empty = 'true';
    status.textContent = '';
    status.dataset.variant = '';
    return;
  }

  const error = validateFile(dropzone, file);
  input.setCustomValidity(error ?? '');
  name.textContent = `${file.name} · ${formatBytes(file.size)}`;
  name.dataset.empty = 'false';
  status.textContent = error || dropzone.dataset.readyLabel || 'Datei ist bereit.';
  status.dataset.variant = error ? 'error' : 'success';

  document.dispatchEvent(new CustomEvent('file-dropzone:change', {
    detail: { id: input.id, file: error ? undefined : file, error },
  }));

  if (!error && dropzone.dataset.autoSubmit === 'true') {
    const form = input.form;
    if (form && form.dataset.autoSubmitting !== 'true') {
      form.dataset.autoSubmitting = 'true';
      window.setTimeout(() => {
        try {
          form.requestSubmit();
        } finally {
          delete form.dataset.autoSubmitting;
        }
      }, 0);
    }
  }
};

const initFileDropzone = (dropzone: HTMLElement): void => {
  if (dropzone.dataset.ready === 'true') return;
  dropzone.dataset.ready = 'true';
  const input = dropzone.querySelector<HTMLInputElement>('[data-file-input]');
  const picker = dropzone.querySelector<HTMLButtonElement>('[data-file-picker]');

  picker?.addEventListener('click', () => input?.click());
  input?.addEventListener('change', () => updateDropzone(dropzone));
  dropzone.addEventListener('dragenter', (event) => { event.preventDefault(); dropzone.dataset.dragging = 'true'; });
  dropzone.addEventListener('dragover', (event) => { event.preventDefault(); dropzone.dataset.dragging = 'true'; });
  dropzone.addEventListener('dragleave', (event) => {
    if (!dropzone.contains(event.relatedTarget as Node | null)) dropzone.dataset.dragging = 'false';
  });
  dropzone.addEventListener('drop', (event) => {
    event.preventDefault();
    dropzone.dataset.dragging = 'false';
    if (!input || !event.dataTransfer?.files.length) return;
    const transfer = new DataTransfer();
    transfer.items.add(event.dataTransfer.files[0]);
    input.files = transfer.files;
    input.dispatchEvent(new Event('change', { bubbles: true }));
  });
};

document.querySelectorAll<HTMLElement>('[data-file-dropzone]').forEach(initFileDropzone);
