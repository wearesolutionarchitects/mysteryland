let sequence = 0;

function createView(root: HTMLElement, select: HTMLSelectElement) {
  const trigger = document.createElement('button');
  trigger.type = 'button';
  trigger.className = 'fanieng-button button button--secondary searchable-select__trigger';
  trigger.setAttribute('aria-haspopup', 'listbox');
  trigger.setAttribute('aria-expanded', 'false');
  const labels = [...select.labels ?? []].map(label => {
    const copy = label.cloneNode(true) as HTMLElement;
    copy.querySelectorAll('select, option, button, input, .searchable-select').forEach(node => node.remove());
    return copy.textContent?.trim() ?? '';
  }).filter(Boolean).join(' ');
  trigger.setAttribute('aria-label', select.getAttribute('aria-label') || labels || select.name || 'Auswählen');
  for (const attribute of ['aria-labelledby', 'aria-describedby', 'title']) {
    if (select.hasAttribute(attribute)) trigger.setAttribute(attribute, select.getAttribute(attribute)!);
  }
  const label = document.createElement('span');
  label.dataset.searchableLabel = '';
  label.textContent = select.selectedOptions[0]?.label ?? 'Auswählen …';
  const arrow = document.createElement('span');
  arrow.textContent = '⌄'; arrow.setAttribute('aria-hidden', 'true');
  trigger.append(label, arrow);
  const panel = document.createElement('div');
  panel.className = 'searchable-select__panel'; panel.hidden = true;
  const search = document.createElement('input');
  search.type = 'search'; search.className = 'searchable-select__search text-field';
  search.placeholder = root.dataset.searchPlaceholder || 'Tippen zum Filtern …'; search.setAttribute('aria-label', 'Auswahl filtern'); search.autocomplete = 'off';
  const list = document.createElement('div');
  list.className = 'searchable-select__options'; list.setAttribute('role', 'listbox');
  panel.append(search, list); root.append(trigger, panel);
}


type SelectOption = { value: string | number; label: string };
export function initializeSearchableSelect(root: HTMLElement, native: HTMLSelectElement) {
  if (root.dataset.ready) return;
  root.dataset.ready = 'true';
  createView(root, native);
  const originalTabIndex = native.getAttribute('tabindex');
  const originalAriaHidden = native.getAttribute('aria-hidden');
  native.dataset.searchableEnhanced = '';
  native.tabIndex = -1;
  native.setAttribute('aria-hidden', 'true');
  const lifecycle = new AbortController();
  const listenerOptions = { signal: lifecycle.signal };
  const deferred = new Set<ReturnType<typeof setTimeout>>();
  const afterEvent = (callback: () => void) => {
    const timeout = setTimeout(() => { deferred.delete(timeout); if (!lifecycle.signal.aborted) callback(); }, 0);
    deferred.add(timeout);
  };
  let options: SelectOption[] = [];
  const minimum = Number(root.dataset.minQueryLength ?? '3');
  const searchUrl = root.dataset.searchUrl;
  const searchParam = root.dataset.searchParam || 'q';
  const debounceMs = Number(root.dataset.debounceMs ?? '250');
  const maxResults = Number(root.dataset.maxResults ?? '50');
  const emptyText = root.dataset.emptyText || 'Keine Treffer gefunden.';
  const trigger = root.querySelector<HTMLButtonElement>('.searchable-select__trigger');
  const panel = root.querySelector<HTMLElement>('.searchable-select__panel');
  const search = root.querySelector<HTMLInputElement>('.searchable-select__search');
  const list = root.querySelector<HTMLElement>('.searchable-select__options');
  const value = native;
  const label = root.querySelector<HTMLElement>('[data-searchable-label]');
  if (!trigger || !panel || !search || !list || !value || !label) return;
  const searchPlaceholder = search.placeholder;
  const placeholder = label.textContent ?? 'Auswählen …';
  const close = () => { ++requestId; controller?.abort(); if (timer) clearTimeout(timer); if (panel.matches(':popover-open')) panel.hidePopover(); panel.hidden = true; trigger.setAttribute('aria-expanded', 'false'); };
  panel.setAttribute('popover', 'manual');
  panel.id ||= `searchable-panel-${++sequence}`;
  list.id = `${panel.id}-options`;
  trigger.setAttribute('aria-controls', list.id);
  search.setAttribute('aria-controls', list.id);
  list.setAttribute('aria-label', 'Auswahl');
  if (native) {
    label.id = `${panel.id}-label`;
    trigger.setAttribute('aria-describedby', [trigger.getAttribute('aria-describedby'), label.id].filter(Boolean).join(' '));
  }
  const sync = () => {
    options = [...native.options].filter(option => !option.disabled && !option.closest('optgroup:disabled')).map(option => ({ value: option.value, label: option.label }));
    const selectedLabel = native.selectedOptions[0]?.label ?? placeholder;
    if (label.textContent !== selectedLabel) label.textContent = selectedLabel;
    trigger.disabled = native.matches(':disabled');

  };
  const position = () => {
    const rect = trigger.getBoundingClientRect();
    const width = Math.min(Math.max(rect.width, 240), window.innerWidth - 16);
    panel.style.width = `${width}px`;
    panel.style.left = `${Math.max(8, Math.min(rect.left, window.innerWidth - width - 8))}px`;
    const below = window.innerHeight - rect.bottom - 8;
    const above = rect.top - 8;
    panel.style.top = below >= Math.min(320, above) ? `${rect.bottom + 4}px` : 'auto';
    panel.style.bottom = below >= Math.min(320, above) ? 'auto' : `${window.innerHeight - rect.top + 4}px`;
    panel.style.maxHeight = `${Math.max(80, Math.max(below, above) - 8)}px`;
  };
  const open = () => {
    sync();
    if (trigger.disabled) return;
    panel.hidden = false;
    panel.showPopover();
    position();
    trigger.setAttribute('aria-expanded', 'true');
    search.value = '';
    search.focus();
    void render();
  };
  native.addEventListener('change', sync, listenerOptions);
  native.addEventListener('focus', () => trigger.focus(), listenerOptions);
  native.addEventListener('invalid', event => { event.preventDefault(); trigger.setAttribute('aria-invalid', 'true'); open(); search.placeholder = 'Bitte einen Eintrag auswählen'; }, listenerOptions);
  native.form?.addEventListener('reset', event => afterEvent(() => {
    if (event.defaultPrevented || lifecycle.signal.aborted) return;
    sync(); close(); trigger.removeAttribute('aria-invalid'); search.placeholder = searchPlaceholder;
  }), listenerOptions);
  const observer = new MutationObserver(sync);
  if (native) {
    observer.observe(native, { subtree: true, childList: true, attributes: true, characterData: true });
    const fieldset = native.closest('fieldset');
    if (fieldset) observer.observe(fieldset, { attributes: true, attributeFilter: ['disabled'] });
  }
  let requestId = 0;
  let timer: ReturnType<typeof setTimeout> | undefined;
  let controller: AbortController | undefined;
  const renderOptions = (matches: SelectOption[]) => {
    list.replaceChildren(...(matches.length > 0 ? matches.slice(0, searchUrl ? maxResults : matches.length).map((option, index) => {
      const button = document.createElement('button');
      button.type = 'button'; button.className = 'searchable-select__option'; button.setAttribute('role', 'option');
      button.dataset.index = String(index);
      button.setAttribute('aria-selected', String(String(option.value) === value.value));
      button.textContent = option.label;
      button.addEventListener('click', () => {
        if (![...native.options].some(item => item.value === String(option.value))) {
          native.add(new Option(option.label, String(option.value)));
        }
        value.value = String(option.value); label.textContent = option.label;
        value.dispatchEvent(new Event('input', { bubbles: true }));
        value.dispatchEvent(new Event('change', { bubbles: true })); trigger.removeAttribute('aria-invalid'); search.placeholder = searchPlaceholder; close(); trigger.focus();
      });
      return button;
    }) : [Object.assign(document.createElement('p'), { className: 'searchable-select__hint', textContent: emptyText })]));
  };
  const render = async () => {
    const query = search.value.trim().toLocaleLowerCase();
    if (query.length < minimum) {
      controller?.abort();
      if (searchUrl && query.length === 0 && options.length > 0) {
        renderOptions(options);
        return;
      }
      list.replaceChildren(Object.assign(document.createElement('p'), { className: 'searchable-select__hint', textContent: `Mindestens ${minimum} Zeichen eingeben.` }));
      return;
    }
    if (!searchUrl) {
      renderOptions(options.filter((option) => option.label.toLocaleLowerCase().includes(query) || String(option.value).toLocaleLowerCase().includes(query)));
      return;
    }
    const currentRequest = ++requestId;
    controller?.abort(); controller = new AbortController();
    list.replaceChildren(Object.assign(document.createElement('p'), { className: 'searchable-select__hint', textContent: 'Suche …' }));
    try {
      const url = new URL(searchUrl, window.location.href);
      url.searchParams.set(searchParam, search.value.trim());
      const response = await fetch(url, { headers: { accept: 'application/json' }, signal: controller.signal });
      if (!response.ok) throw new Error(`Suche fehlgeschlagen (${response.status})`);
      const payload = await response.json() as SelectOption[] | { options?: SelectOption[] };
      if (currentRequest !== requestId) return;
      const matches = Array.isArray(payload) ? payload : payload.options ?? [];
      renderOptions(matches);
    } catch (error) {
      if (error instanceof DOMException && error.name === 'AbortError') return;
      if (currentRequest === requestId) list.replaceChildren(Object.assign(document.createElement('p'), { className: 'searchable-select__hint searchable-select__hint--error', textContent: 'Suche derzeit nicht verfügbar.' }));
    }
  };
  trigger.addEventListener('click', () => {
    if (panel.hidden) open(); else close();
  }, listenerOptions);
  search.addEventListener('input', () => {
    ++requestId;
    controller?.abort();
    if (timer) clearTimeout(timer);
    timer = setTimeout(() => { void render(); }, searchUrl ? debounceMs : 0);
  }, listenerOptions);
  panel.addEventListener('keydown', (event) => {
    if (event.key === 'Escape') { close(); trigger.focus(); return; }
    const buttons = [...list.querySelectorAll<HTMLButtonElement>('.searchable-select__option')];
    if (!['ArrowDown', 'ArrowUp', 'Enter'].includes(event.key)) return;
    event.preventDefault();
    if (!buttons.length) return;
    const active = buttons.findIndex((button) => button === document.activeElement);
    if (event.key === 'Enter') { buttons[Math.max(active, 0)]?.click(); return; }
    const next = event.key === 'ArrowDown' ? Math.min(active + 1, buttons.length - 1) : Math.max(active - 1, 0);
    buttons[next]?.focus();
  }, listenerOptions);
  document.addEventListener('click', (event) => { if (!root.contains(event.target as Node)) close(); }, listenerOptions);
  root.addEventListener('focusout', () => afterEvent(() => { if (!lifecycle.signal.aborted && !root.contains(document.activeElement)) close(); }), listenerOptions);
  window.addEventListener('resize', close, listenerOptions);
  document.addEventListener('scroll', event => { if (!panel.hidden && !panel.contains(event.target as Node)) position(); }, { ...listenerOptions, capture: true });
  sync();
  label.textContent = value.value ? label.textContent : placeholder;
  return () => {
    close(); observer.disconnect(); lifecycle.abort();
    deferred.forEach(clearTimeout); deferred.clear();
    delete root.dataset.ready;
    delete native.dataset.searchableEnhanced;
    for (const [attribute, previous] of [['tabindex', originalTabIndex], ['aria-hidden', originalAriaHidden]] as const) {
      if (previous === null) native.removeAttribute(attribute); else native.setAttribute(attribute, previous);
    }
    trigger.remove(); panel.remove();
  };
}
